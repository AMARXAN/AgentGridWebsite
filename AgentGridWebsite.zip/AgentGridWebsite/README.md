# AgentGrid

AgentGrid is a responsive workspace UI for coordinating AI agents, reviewing task queues, and monitoring activity.

## MVP features
- Responsive overview dashboard
- Agent directory with locally simulated status controls
- Task creation, search, and status filters
- Activity timeline and notifications UI
- React + TypeScript + Vite
- GitHub Actions workflow for build verification

## Run locally
Requirements: Node.js 20.19+ or 22.12+ and npm.

```bash
npm install
npm run dev
```

## Verify
```bash
npm run typecheck
npm run build
npm run preview
```

## Deployment
Deploy the Vite static build to any static hosting provider. Build command: `npm run build`; output directory: `dist/`.

## Important scope and security notes
This is a frontend MVP using sample data. Agent controls and task queues only change local UI state; no AI agent execution, account authentication, billing, or persistence is connected. Before production use, implement server-side authentication and authorization, persistent storage, API validation, rate limiting, audit logs, monitoring, automated tests, and safe sandboxing for any model-generated commands. Never commit secrets or `.env` files.

No license has been selected yet. Add a license before permitting reuse.
