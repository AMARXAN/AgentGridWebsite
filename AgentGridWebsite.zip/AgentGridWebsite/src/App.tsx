import { useMemo, useState } from 'react'
import {
  Activity, ArrowRight, ArrowUpRight, Bell, Bot, Check, ChevronDown,
  ChevronRight, CircleHelp, Clock3, Command, FileText, Filter, LayoutDashboard,
  LifeBuoy, Menu, MoreHorizontal, PanelLeftClose, Plus, Search, Settings2,
  ShieldCheck, Sparkles, Workflow, Users, X, Zap,
} from 'lucide-react'

type AgentStatus = 'Running' | 'Idle' | 'Needs review'
type TaskStatus = 'In progress' | 'Queued' | 'Completed' | 'Failed'
type Agent = { id: number; name: string; role: string; initials: string; color: string; status: AgentStatus; tasks: number; model: string }
type Task = { id: string; title: string; agent: string; status: TaskStatus; updated: string; priority: 'High' | 'Medium' | 'Low' }

const seedAgents: Agent[] = [
  { id: 1, name: 'Atlas Researcher', role: 'Research & synthesis', initials: 'AR', color: 'violet', status: 'Running', tasks: 12, model: 'Claude 3.5 Sonnet' },
  { id: 2, name: 'Nova Writer', role: 'Content & communication', initials: 'NW', color: 'blue', status: 'Running', tasks: 8, model: 'GPT-4o' },
  { id: 3, name: 'Pixel Designer', role: 'Product & visual design', initials: 'PD', color: 'pink', status: 'Idle', tasks: 5, model: 'GPT-4o' },
  { id: 4, name: 'Sage Analyst', role: 'Data & insights', initials: 'SA', color: 'green', status: 'Needs review', tasks: 4, model: 'Claude 3.5 Sonnet' },
]
const seedTasks: Task[] = [
  { id: 'AG-2481', title: 'Synthesize customer interview notes', agent: 'Atlas Researcher', status: 'In progress', updated: '2 min ago', priority: 'High' },
  { id: 'AG-2480', title: 'Draft Q4 product announcement', agent: 'Nova Writer', status: 'In progress', updated: '8 min ago', priority: 'Medium' },
  { id: 'AG-2479', title: 'Analyze onboarding conversion', agent: 'Sage Analyst', status: 'Queued', updated: '14 min ago', priority: 'High' },
  { id: 'AG-2478', title: 'Explore dashboard visual directions', agent: 'Pixel Designer', status: 'Completed', updated: '31 min ago', priority: 'Low' },
  { id: 'AG-2477', title: 'Summarize competitor release notes', agent: 'Atlas Researcher', status: 'Completed', updated: '46 min ago', priority: 'Medium' },
]
const events = [
  { icon: Check, tone: 'green', title: 'Task completed', detail: 'Pixel Designer finished “Explore dashboard visual directions”', time: '8 min ago' },
  { icon: ShieldCheck, tone: 'blue', title: 'Approval requested', detail: 'Sage Analyst needs review on a data summary', time: '19 min ago' },
  { icon: Zap, tone: 'violet', title: 'Agent run started', detail: 'Atlas Researcher began a new research workflow', time: '34 min ago' },
  { icon: Users, tone: 'amber', title: 'Workspace updated', detail: 'A teammate added a new task to the queue', time: '1 hr ago' },
]
const statusClass: Record<string, string> = {
  Running: 'status-running', Idle: 'status-idle', 'Needs review': 'status-review',
  'In progress': 'status-progress', Queued: 'status-queued', Completed: 'status-completed', Failed: 'status-failed',
}

export default function App() {
  const [activeNav, setActiveNav] = useState('Overview')
  const [agents, setAgents] = useState(seedAgents)
  const [tasks, setTasks] = useState(seedTasks)
  const [taskFilter, setTaskFilter] = useState('All tasks')
  const [search, setSearch] = useState('')
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [showCreate, setShowCreate] = useState(false)
  const [newTask, setNewTask] = useState('')
  const [selectedAgent, setSelectedAgent] = useState('Atlas Researcher')
  const [notice, setNotice] = useState('')
  const [notificationsOpen, setNotificationsOpen] = useState(false)

  const filteredTasks = useMemo(() => tasks.filter(task => {
    const matchesFilter = taskFilter === 'All tasks' || task.status === taskFilter
    const matchesSearch = (task.title + task.agent + task.id).toLowerCase().includes(search.toLowerCase())
    return matchesFilter && matchesSearch
  }), [tasks, taskFilter, search])

  function notify(message: string) {
    setNotice(message)
    window.setTimeout(() => setNotice(''), 3000)
  }
  function addTask() {
    const title = newTask.trim()
    if (!title) return
    setTasks(current => [{ id: `AG-${2482 + current.length - seedTasks.length}`, title, agent: selectedAgent, status: 'Queued', updated: 'Just now', priority: 'Medium' }, ...current])
    setNewTask('')
    setShowCreate(false)
    setActiveNav('Tasks')
    setTaskFilter('All tasks')
    notify('Task added to the queue')
  }
  function toggleAgent(id: number) {
    setAgents(current => current.map(agent => agent.id === id ? { ...agent, status: agent.status === 'Running' ? 'Idle' : 'Running' } : agent))
    notify('Agent status updated locally')
  }

  const navGroups = [
    { label: 'WORKSPACE', items: [{ label: 'Overview', icon: LayoutDashboard }, { label: 'Agents', icon: Bot, count: '4' }, { label: 'Tasks', icon: Workflow, count: String(tasks.length) }, { label: 'Activity', icon: Activity }] },
    { label: 'MANAGE', items: [{ label: 'Knowledge base', icon: FileText }, { label: 'Integrations', icon: Command }] },
  ]

  return <div className="app-shell">
    {sidebarOpen && <button className="mobile-scrim" aria-label="Close menu" onClick={() => setSidebarOpen(false)} />}
    <aside className={`sidebar ${sidebarOpen ? 'sidebar-open' : ''}`}>
      <div className="brand-row"><div className="brand-mark"><Workflow size={21} /></div><span className="brand-name">agent<span>grid</span></span><button className="icon-button sidebar-collapse" aria-label="Sidebar options" onClick={() => notify('Sidebar preferences are local in this demo')}><PanelLeftClose size={17} /></button></div>
      <button className="workspace-switcher" onClick={() => notify('Workspace switching requires an account backend')}><div className="workspace-avatar">A</div><div className="workspace-copy"><strong>Acme Studio</strong><span>Free workspace</span></div><ChevronDown size={15} className="muted-icon" /></button>
      <nav className="nav-groups" aria-label="Main navigation">{navGroups.map(group => <div className="nav-group" key={group.label}><div className="nav-heading">{group.label}</div>{group.items.map(item => { const Icon = item.icon; return <button key={item.label} className={`nav-item ${activeNav === item.label ? 'nav-item-active' : ''}`} onClick={() => { setActiveNav(item.label); setSidebarOpen(false) }}><Icon size={17} /><span>{item.label}</span>{'count' in item && <span className="nav-count">{item.count}</span>}</button> })}</div>)}</nav>
      <div className="sidebar-spacer" />
      <div className="usage-card"><div className="usage-title"><span>Monthly usage</span><span className="usage-percent">68%</span></div><div className="usage-bar"><span /></div><p>6,820 of 10,000 credits used</p><button onClick={() => notify('Billing is not connected in this MVP')}>Manage plan <ArrowRight size={13} /></button></div>
      <button className="nav-item bottom-nav" onClick={() => setActiveNav('Settings')}><Settings2 size={17} /><span>Settings</span></button>
      <button className="nav-item bottom-nav" onClick={() => notify('Help center is not connected yet')}><LifeBuoy size={17} /><span>Help & support</span></button>
      <div className="profile-row"><div className="profile-avatar">AM</div><div className="profile-copy"><strong>Amarxan</strong><span>Owner · Demo profile</span></div><MoreHorizontal size={18} className="muted-icon" /></div>
    </aside>

    <main className="main-area">
      <header className="topbar"><div className="breadcrumb"><button className="mobile-menu icon-button" aria-label="Open menu" onClick={() => setSidebarOpen(true)}><Menu size={20} /></button><span>Workspace</span><ChevronRight size={14} /><strong>{activeNav}</strong></div><div className="topbar-actions"><label className="search-box"><Search size={16} /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search tasks..." aria-label="Search workspace" /><kbd>⌘ K</kbd></label><div className="notification-wrap"><button className="icon-button notification-button" aria-label="Notifications" onClick={() => setNotificationsOpen(!notificationsOpen)}><Bell size={18} /><i /></button>{notificationsOpen && <div className="notification-popover"><strong>Notifications</strong><p><span className="dot dot-amber" /> Sage Analyst is waiting for review.</p><p><span className="dot dot-green" /> Pixel Designer completed a task.</p><button onClick={() => { setNotificationsOpen(false); setActiveNav('Activity') }}>View activity <ArrowRight size={13} /></button></div>}</div><button className="help-button" onClick={() => notify('Help center is coming soon')}><CircleHelp size={17} /><span>Help</span></button></div></header>
      <div className="page-content">
        {activeNav === 'Overview' && <Overview agents={agents} tasks={tasks} setActiveNav={setActiveNav} onCreate={() => setShowCreate(true)} onToggleAgent={toggleAgent} notify={notify} />}
        {activeNav === 'Agents' && <AgentsPage agents={agents} onToggle={toggleAgent} onCreate={() => notify('Agent builder is the next milestone')} />}
        {activeNav === 'Tasks' && <TasksPage tasks={filteredTasks} filter={taskFilter} setFilter={setTaskFilter} onCreate={() => setShowCreate(true)} />}
        {activeNav === 'Activity' && <ActivityPage />}
        {activeNav === 'Knowledge base' && <PlaceholderPage icon={<FileText size={23} />} title="Knowledge base" description="Give your agents shared context, documents, and reliable sources." action="Add a source" onAction={() => notify('Knowledge source integration is not configured')} />}
        {activeNav === 'Integrations' && <PlaceholderPage icon={<Command size={23} />} title="Integrations" description="Connect the tools your team already uses and bring work into one place." action="Browse integrations" onAction={() => notify('Integration catalog is coming soon')} />}
        {activeNav === 'Settings' && <PlaceholderPage icon={<Settings2 size={23} />} title="Workspace settings" description="Manage workspace details, access, and usage preferences." action="Edit workspace" onAction={() => notify('Settings API is not connected')} />}
      </div>
    </main>

    {showCreate && <div className="modal-backdrop" onClick={e => { if (e.target === e.currentTarget) setShowCreate(false) }}><section className="create-modal" role="dialog" aria-modal="true" aria-labelledby="create-title"><div className="modal-heading"><div><span className="eyebrow">NEW WORKFLOW</span><h2 id="create-title">Create a task</h2><p>Describe the outcome you want your agent to deliver.</p></div><button className="icon-button" onClick={() => setShowCreate(false)} aria-label="Close"><X size={19} /></button></div><form onSubmit={e => { e.preventDefault(); addTask() }}><label className="field-label" htmlFor="task-title">Task description</label><textarea id="task-title" value={newTask} onChange={e => setNewTask(e.target.value)} placeholder="e.g. Research the top 5 competitors and summarize their positioning..." rows={4} required /><label className="field-label" htmlFor="task-agent">Assign to agent</label><select id="task-agent" value={selectedAgent} onChange={e => setSelectedAgent(e.target.value)}>{agents.map(agent => <option key={agent.id}>{agent.name}</option>)}</select><div className="modal-note"><Sparkles size={16} /><span>This demo queues tasks locally in your browser. No agent will execute the task yet.</span></div><div className="modal-footer"><button type="button" className="button-secondary" onClick={() => setShowCreate(false)}>Cancel</button><button type="submit" className="button-primary"><Plus size={16} /> Add to queue</button></div></form></section></div>}
    {notice && <div className="toast" role="status"><Check size={16} />{notice}<button onClick={() => setNotice('')} aria-label="Dismiss"><X size={14} /></button></div>}
  </div>
}

function PageHeader({ eyebrow, title, description, action }: { eyebrow: string; title: string; description: string; action?: React.ReactNode }) {
  return <div className="page-header"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{description}</p></div>{action}</div>
}
function Overview({ agents, tasks, setActiveNav, onCreate, onToggleAgent, notify }: { agents: Agent[]; tasks: Task[]; setActiveNav: (value: string) => void; onCreate: () => void; onToggleAgent: (id: number) => void; notify: (message: string) => void }) {
  const completed = tasks.filter(task => task.status === 'Completed').length + 124
  return <>
    <PageHeader eyebrow="YOUR AI WORKSPACE" title="Good afternoon, Amarxan" description="Here's what's happening across your AI workspace today." action={<button className="button-primary" onClick={onCreate}><Plus size={16} /> Create task</button>} />
    <div className="welcome-banner"><div className="banner-orb orb-one" /><div className="banner-content"><div className="banner-icon"><Sparkles size={19} /></div><div><div className="banner-kicker">YOUR AI WORKSPACE</div><h2>Good work happens when agents work together.</h2><p>You've saved an estimated 12.4 hours this month with AgentGrid.</p></div></div><button className="banner-link" onClick={() => notify('Analytics will be connected to real usage data later')}>Explore insights <ArrowRight size={15} /></button></div>
    <div className="section-heading"><div><h2>Workspace overview</h2><p>Performance at a glance · demo data</p></div><button className="subtle-button" onClick={() => notify('Showing the last 30 days')}><Clock3 size={14} /> Last 30 days <ChevronDown size={14} /></button></div>
    <div className="metrics-grid"><MetricCard icon={<Bot size={18} />} tone="violet" label="Active agents" value={String(agents.filter(a => a.status === 'Running').length)} trend="+2" note="vs. last month" trendUp /><MetricCard icon={<Workflow size={18} />} tone="blue" label="Tasks completed" value={String(completed)} trend="+18.6%" note="vs. last month" trendUp /><MetricCard icon={<Zap size={18} />} tone="amber" label="Credits used" value="6,820" trend="68%" note="of monthly limit" /><MetricCard icon={<Clock3 size={18} />} tone="green" label="Time saved" value="12.4h" trend="+24%" note="vs. last month" trendUp /></div>
    <div className="content-grid"><section className="panel"><div className="panel-heading"><div><h2>Your agents</h2><p>Manage your AI team</p></div><button className="text-link" onClick={() => setActiveNav('Agents')}>View all <ArrowRight size={14} /></button></div><div>{agents.map(agent => <AgentRow key={agent.id} agent={agent} onToggle={() => onToggleAgent(agent.id)} />)}</div><button className="panel-bottom-link" onClick={() => notify('Agent builder is the next milestone')}><Plus size={15} /> Create new agent</button></section>
      <section className="panel"><div className="panel-heading"><div><h2>Recent tasks</h2><p>Latest work across your agents</p></div><button className="text-link" onClick={() => setActiveNav('Tasks')}>View all <ArrowRight size={14} /></button></div><div>{tasks.slice(0, 4).map(task => <div className="recent-task" key={task.id}><div className={`task-icon ${task.status === 'Completed' ? 'task-icon-done' : task.status === 'Queued' ? 'task-icon-queued' : 'task-icon-active'}`}>{task.status === 'Completed' ? <Check size={15} /> : task.status === 'Queued' ? <Clock3 size={15} /> : <Activity size={15} />}</div><div className="recent-task-main"><strong>{task.title}</strong><span>{task.agent} · {task.updated}</span></div><span className={`status-pill ${statusClass[task.status]}`}>{task.status}</span></div>)}</div><button className="panel-bottom-link" onClick={() => setActiveNav('Tasks')}><Workflow size={15} /> Open task manager</button></section></div>
    <div className="content-grid lower-grid"><section className="panel"><div className="panel-heading"><div><h2>Recent activity</h2><p>Workspace event feed · demo data</p></div><button className="text-link" onClick={() => setActiveNav('Activity')}>View activity <ArrowRight size={14} /></button></div>{events.slice(0, 3).map((item, i) => { const Icon = item.icon; return <div className="activity-item" key={item.title}><div className={`activity-icon activity-${item.tone}`}><Icon size={15} /></div><div className="activity-copy"><strong>{item.title}</strong><span>{item.detail}</span></div><time>{item.time}</time>{i < 2 && <div className="activity-line" />}</div> })}</section>
      <section className="panel performance-panel"><div className="panel-heading"><div><h2>Task performance</h2><p>Completed tasks this week · sample</p></div><button className="icon-button" aria-label="Performance options" onClick={() => notify('Performance options')}><MoreHorizontal size={18} /></button></div><div className="performance-total"><strong>128</strong><span className="trend-positive"><ArrowUpRight size={14} /> 18.6%</span><span className="performance-caption">tasks completed</span></div><div className="chart" role="img" aria-label="Sample bar chart showing tasks increasing through the week">{[36,54,43,72,59,85,68,94,76,100,81,91,69,88].map((height, i) => <div key={i} className={`chart-bar ${i === 9 ? 'chart-bar-highlight' : ''}`} style={{ height: `${height}%` }} />)}</div><div className="chart-labels"><span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span><span>Sun</span></div></section></div>
  </>
}
function MetricCard({ icon, tone, label, value, trend, note, trendUp }: { icon: React.ReactNode; tone: string; label: string; value: string; trend: string; note: string; trendUp?: boolean }) {
  return <div className="metric-card"><div className="metric-top"><div className={`metric-icon metric-${tone}`}>{icon}</div><span className={trendUp ? 'metric-trend trend-positive' : 'metric-trend'}>{trendUp && <ArrowUpRight size={13} />}{trend}</span></div><div className="metric-label">{label}</div><div className="metric-value">{value}</div><div className="metric-note">{note}</div></div>
}
function AgentRow({ agent, onToggle }: { agent: Agent; onToggle: () => void }) {
  return <div className="agent-row"><div className={`agent-avatar avatar-${agent.color}`}>{agent.initials}</div><div className="agent-main"><strong>{agent.name}</strong><span>{agent.role}</span></div><div className="agent-row-meta"><span className={`status-dot ${statusClass[agent.status]}`} /><span>{agent.status}</span><span className="agent-task-count">{agent.tasks} tasks</span></div><button className="icon-button row-more" aria-label={`Toggle ${agent.name}`} title={agent.status === 'Running' ? 'Pause agent' : 'Start agent'} onClick={onToggle}><MoreHorizontal size={17} /></button></div>
}
function AgentsPage({ agents, onToggle, onCreate }: { agents: Agent[]; onToggle: (id: number) => void; onCreate: () => void }) {
  return <><PageHeader eyebrow="YOUR AI TEAM" title="Agents" description="Manage the specialized agents that help your team get work done." action={<button className="button-primary" onClick={onCreate}><Plus size={16} /> New agent</button>} /><div className="agent-page-grid">{agents.map(agent => <div className="agent-card" key={agent.id}><div className="agent-card-top"><div className={`agent-avatar agent-avatar-large avatar-${agent.color}`}>{agent.initials}</div><button className="icon-button" onClick={() => onToggle(agent.id)} aria-label="Toggle agent"><MoreHorizontal size={18} /></button></div><h3>{agent.name}</h3><p>{agent.role}</p><div className="agent-card-status"><span className={`status-dot ${statusClass[agent.status]}`} />{agent.status}</div><div className="agent-card-stats"><div><span>Tasks handled</span><strong>{agent.tasks}</strong></div><div><span>Model</span><strong>{agent.model}</strong></div></div><button className="button-secondary button-full" onClick={() => onToggle(agent.id)}>{agent.status === 'Running' ? 'Pause agent' : 'Start agent'}</button></div>)}</div><div className="info-callout"><ShieldCheck size={18} /><div><strong>Human oversight stays in control</strong><p>Agent controls are simulated in this frontend MVP. Connect a secure backend before using them to run real workloads.</p></div></div></>
}
function TasksPage({ tasks, filter, setFilter, onCreate }: { tasks: Task[]; filter: string; setFilter: (value: string) => void; onCreate: () => void }) {
  const filters = ['All tasks', 'In progress', 'Queued', 'Completed', 'Failed']
  return <><PageHeader eyebrow="WORK MANAGEMENT" title="Tasks" description="Track every run, review progress, and keep work moving." action={<button className="button-primary" onClick={onCreate}><Plus size={16} /> Create task</button>} /><section className="panel task-table-panel"><div className="table-toolbar"><div className="filter-tabs">{filters.map(f => <button key={f} className={filter === f ? 'filter-tab filter-tab-active' : 'filter-tab'} onClick={() => setFilter(f)}>{f}</button>)}</div><button className="subtle-button" onClick={() => setFilter('All tasks')}><Filter size={14} /> Reset filters</button></div><div className="task-table-wrap"><table className="task-table"><thead><tr><th>Task</th><th>Assigned agent</th><th>Status</th><th>Priority</th><th>Updated</th><th /></tr></thead><tbody>{tasks.map(task => <tr key={task.id}><td><span className="task-id">{task.id}</span><strong>{task.title}</strong></td><td><span className="table-agent"><span className="table-agent-dot">{task.agent.split(' ').map(s => s[0]).join('').slice(0,2)}</span>{task.agent}</span></td><td><span className={`status-pill ${statusClass[task.status]}`}>{task.status}</span></td><td><span className={`priority priority-${task.priority.toLowerCase()}`}><span />{task.priority}</span></td><td className="table-time">{task.updated}</td><td><button className="icon-button" aria-label={`Options for ${task.id}`} onClick={() => setFilter(task.status)}><MoreHorizontal size={17} /></button></td></tr>)}</tbody></table>{tasks.length === 0 && <div className="empty-state"><Workflow size={26} /><strong>No tasks found</strong><p>Try another filter or create a new task.</p></div>}</div><div className="table-footer"><span>Showing {tasks.length} tasks</span><span>Demo workspace</span></div></section></>
}
function ActivityPage() {
  return <><PageHeader eyebrow="WORKSPACE HISTORY" title="Activity" description="A timeline of important events across your workspace." /><section className="panel full-activity-panel"><div className="panel-heading"><div><h2>Today</h2><p>Recent agent runs and workspace updates · sample events</p></div><button className="subtle-button"><Filter size={14} /> Filter activity</button></div>{events.map((item, i) => { const Icon = item.icon; return <div className="full-activity-row" key={item.title}><div className={`activity-icon activity-${item.tone}`}><Icon size={16} /></div><div className="activity-copy"><strong>{item.title}</strong><span>{item.detail}</span></div><time>{item.time}</time>{i === 0 && <span className="new-event">NEW</span>}</div> })}</section></>
}
function PlaceholderPage({ icon, title, description, action, onAction }: { icon: React.ReactNode; title: string; description: string; action: string; onAction: () => void }) {
  return <div className="placeholder-wrap"><div className="placeholder-card"><div className="placeholder-icon">{icon}</div><div className="eyebrow">AGENTGRID WORKSPACE</div><h1>{title}</h1><p>{description}</p><button className="button-primary" onClick={onAction}>{action} <ArrowRight size={15} /></button><span className="placeholder-footnote">This section is scaffolded for the next product milestone.</span></div></div>
}
